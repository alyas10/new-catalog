﻿
class Device
{
    public string Type { get; set; }
    public string CPU { get; set; }
    public string GPU { get; set; }
    public int RAM { get; set; }
    public override string ToString()
    {
        return $"Type: {Type} \n" +
            $"CPU {CPU}" +
            $"\n GPU {GPU} " +
            $"\n RAM {RAM}";

    }
}

// interface
 abstract class Builder
{
    public abstract void setType(string type);
    public abstract void setCPU(string cpu);
    public abstract void setGPU(string gpu);
    public abstract void setRAM(int ram);

    public abstract Device GetDevice();
}

class ComputerBuilder : Builder
{
    //принцип открытости-закрытости
    private Device device = new Device();

    internal Device Device
    {
        get => default;
        set
        {
        }
    }

    public override void setType(string type) => device.Type = type;
    public override void setCPU(string cpu) => device.CPU = cpu;

    public override void setGPU(string gpu) => device.GPU = gpu;

    public override void setRAM(int ram) => device.RAM = ram;
    public override Device GetDevice() => device;
}

class Director
{
    public void BuildLaptop(Builder builder)
    {
        builder.setType("Ноутбук");
        builder.setCPU("AMD Ryzen 7");
        builder.setGPU("AMD Graphics");
        builder.setRAM(8);
    }
    public void BuildPC(Builder builder)
    {
        builder.setType("Персональный компьютер");
        builder.setCPU("Intel Core i5");
        builder.setGPU("NVIDIA GeForce RTX 4070");
        builder.setRAM(32);
    }
}
internal class Program
{
    private static void Main(string[] args)
    {
        var director = new Director();
        var builder = new ComputerBuilder();
        director.BuildLaptop(builder);
        Console.WriteLine(builder.GetDevice().ToString());
        director.BuildPC(builder);
        Console.WriteLine(builder.GetDevice().ToString());
    }
}