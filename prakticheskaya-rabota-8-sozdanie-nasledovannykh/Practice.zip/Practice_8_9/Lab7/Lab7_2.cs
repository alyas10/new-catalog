﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*Задание 2
Создать класс Human с полями: ФИО, дата рождения (строка "дд.мм.гггг").
Реализовать метод GetAge(), возвращающий возраст в годах (текущий год минус год рождения).
Создать производный класс BankClient с полем — тип клиента ("VIP"/"Стандарт").
Добавить метод GetDiscount(), возвращающий скидку: 5% для стандартных, 10% для VIP.
*/

namespace Practice_8_9.Lab8
{
    internal class Lab7_2
    {
        public static void Test()
        {
            Human h = new Human("Иванов И.И.", "15.03.1990");
            h.PrintInfo();

            BankClient client = new BankClient("Петров П.П.", "20.05.1985", "VIP");
            client.PrintInfo();
            Console.WriteLine($"Скидка: {client.GetDiscount() * 100}%");

        }
    }
    class Human
    {
        public string FullName { get; set; }
        public string BirthDate { get; set; } // "дд.мм.гггг"

        public Human(string fullName, string birthDate)
        {
            FullName = fullName;
            BirthDate = birthDate;
        }

        public virtual int GetAge()
        {
            int birthYear = int.Parse(BirthDate.Substring(6));
            return DateTime.Now.Year - birthYear;
        }

        public virtual void PrintInfo()
        {
            Console.WriteLine($"{FullName}, {GetAge()} лет");
        }
    }

    class BankClient : Human
    {
        public string ClientType { get; set; } // "VIP"/"Стандарт"

        public BankClient(string fullName, string birthDate, string clientType)
            : base(fullName, birthDate)
        {
            ClientType = clientType;
        }

        public override void PrintInfo()
        {
            Console.WriteLine($"{FullName}, {GetAge()} лет, тип: {ClientType}");
        }

        public double GetDiscount()
        {
            return ClientType == "VIP" ? 0.10 : 0.05;
        }
    }

}
