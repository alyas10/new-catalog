﻿
/*
 * Задание 1
Создать класс Pair (пара целых чисел - начальный и конечный баланс счета);
Определить метод умножения на число (процентная ставка) и операцию сложения пар: (начальный, конечный) + (начальный2, конечный2).
Определить класс-наследник BankAccount с полями: номер счета (string), валюта (string).
Переопределить операцию сложения и определить методы вычитания и деления денежных сумм.
*/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Practice_8_9.Lab8
{
    public class Lab7_1
    {
        public static void Test()
        {
            Pair p1 = new Pair(1000, 1200);
            Pair p2 = new Pair(500, 600);
            Console.WriteLine(p1 + p2); // (1500, 1800)
            Console.WriteLine(p1.Multiply(2)); // (2000, 2400)

            BankAccount acc1 = new BankAccount("ACC001", "RUB", 1000, 1200);
            BankAccount acc2 = new BankAccount("ACC002", "RUB", 500, 600);
            Console.WriteLine(acc1 + acc2);
            Console.WriteLine(acc1 - acc2);
            Console.WriteLine(acc1.Divide(2));
        }

        }
    }
   public class Pair
    {
    public int First { get; set; }
    public int Second { get; set; }

    public Pair(int first, int second)
    {
        First = first;
        Second = second;
    }

    // Умножение на число (процентная ставка)
    public Pair Multiply(int multiplier)
    {
        return new Pair(First * multiplier, Second * multiplier);
    }

    // Сложение пар
    public static Pair operator +(Pair a, Pair b)
    {
        return new Pair(a.First + b.First, a.Second + b.Second);
    }

    public override string ToString()
    {
        return $"({First}, {Second})";
    }
}

class BankAccount : Pair
{
    public string AccountNumber { get; set; }
    public string Currency { get; set; }

    public BankAccount(string accountNumber, string currency, int first, int second)
        : base(first, second)
    {
        AccountNumber = accountNumber;
        Currency = currency;
    }

    // Переопределение сложения
    public static BankAccount operator +(BankAccount a, BankAccount b)
    {
        return new BankAccount(
            $"Combined_{a.AccountNumber}_{b.AccountNumber}",
            a.Currency,
            a.First + b.First,
            a.Second + b.Second);
    }

    // Вычитание
    public static BankAccount operator -(BankAccount a, BankAccount b)
    {
        return new BankAccount(
            $"{a.AccountNumber}_minus_{b.AccountNumber}",
            a.Currency,
            a.First - b.First,
            a.Second - b.Second);
    }

    // Деление
    public BankAccount Divide(int divisor)
    {
        return new BankAccount(
            AccountNumber + "_divided",
            Currency,
            First / divisor,
            Second / divisor);
    }

    public override string ToString()
    {
        return $"Счет {AccountNumber} ({Currency}): {base.ToString()}";
    }
}

