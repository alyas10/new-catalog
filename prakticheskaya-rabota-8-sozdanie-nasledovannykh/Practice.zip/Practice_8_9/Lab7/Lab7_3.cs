﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*Создать класс Animal с полями: вид, кличка, вес (кг).
Реализовать виртуальный метод GetFoodAmount(), возвращающий дневную норму корма (вес * 0.05 кг).
Создать производный класс BankSecurityDog с полем — уровень подготовки ("низкий"/"средний"/"высокий").
Переопределить GetFoodAmount(): базовая норма + бонус за уровень подготовки (низкий:+10%, средний:+20%, высокий:+30%).
*/

namespace Practice_8_9.Lab8
{
    internal class Lab7_3
    {
        public static void Test()
        {
            Animal dog = new BankSecurityDog("Рекс", 30, "высокий");
            Console.WriteLine(dog);
            Console.WriteLine($"Норма корма: {dog.GetFoodAmount():F2} кг/день");

            Animal genericDog = new Animal("Собака", "Бобик", 25);
            Console.WriteLine(genericDog);
            Console.WriteLine($"Норма корма: {genericDog.GetFoodAmount():F2} кг/день");

        }
    }
    class Animal
    {
        public string Species { get; set; }
        public string Name { get; set; }
        public double Weight { get; set; }

        public Animal(string species, string name, double weight)
        {
            Species = species;
            Name = name;
            Weight = weight;
        }

        public virtual double GetFoodAmount()
        {
            return Weight * 0.05; // Базовая норма
        }

        public override string ToString()
        {
            return $"{Species} {Name}, вес {Weight} кг";
        }
    }

    class BankSecurityDog : Animal
    {
        public string TrainingLevel { get; set; } // "низкий"/"средний"/"высокий"

        public BankSecurityDog(string name, double weight, string trainingLevel)
            : base("Собака охраны", name, weight)
        {
            TrainingLevel = trainingLevel;
        }

        public override double GetFoodAmount()
        {
            double bonus = TrainingLevel switch
            {
                "низкий" => 1.10,
                "средний" => 1.20,
                "высокий" => 1.30,
                _ => 1.0
            };
            return base.GetFoodAmount() * bonus;
        }
    }


}
