﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*Создать класс Book.
● В классе Book должны быть закрытое (private) поле title строкового типа, публичное (public) поле Pages целочисленного типа и методы, устанавливающие и возвращающие данные значения («геттеры» «сеттеры»);
● Класс Book должен иметь конструктор, принимающий в качестве аргумента только title, и конструктор, принимающий два аргумента;
● Класс Book должен иметь публичный метод – функцию WriteInfo(), которая возвращает информацию о книге в виде строки;
● Класс Book должен иметь публичный метод – процедуру AddPages(int n), изменяющую Pages;
● Создать три объекта класса Book различными способами;*/

namespace Practice_8_9.Lab9
{
    internal class Lab8_1
    {
        public static void Test()
        {
            Book b1 = new Book("Война и мир");
            Book b2 = new Book("1984", 400);
            Book b3 = new Book("Гарри Поттер");
            b3.Pages = 350;

            Console.WriteLine(b1.WriteInfo());
            Console.WriteLine(b2.WriteInfo());
            Console.WriteLine(b3.WriteInfo());
        }
    }
    class Book
    {
        private string title;
        public int Pages;

        public string GetTitle() { return title; }
        public void SetTitle(string value) { title = value; }

        public Book(string title)
        {
            this.title = title;
            Pages = 0;
        }

        public Book(string title, int pages)
        {
            this.title = title;
            Pages = pages;
        }

        public string WriteInfo()
        {
            return $"Книга: {title}, страниц: {Pages}";
        }

        public void AddPages(int n)
        {
            Pages += n;
        }
    }


}
