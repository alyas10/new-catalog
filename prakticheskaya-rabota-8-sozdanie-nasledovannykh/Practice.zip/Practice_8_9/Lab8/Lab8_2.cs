﻿using System;

/*
  Создать для класса Book базовый абстрактный класс Publication, имеющий хотя бы одно абстрактное поле и один абстрактный метод;
Разработать для класса Book производный класс EBook;
Продемонстрировать на примере классов Book и EBook различие между переопределением (override) и скрытием метода (new);
*/
namespace Practice_8_9.Lab9
{
    internal class Lab8_2
    {
        public void Test()
        {
            Publication pub1 = new Book2("Война и мир", 1200);
            Publication pub2 = new EBook("1984", "PDF");
            pub1.PrintInfo(); // Вызовет Book2.PrintInfo() (override)
            pub2.PrintInfo(); // Вызовет EBook.PrintInfo() (new)

            EBook ebook = new EBook("Гарри Поттер", "EPUB");
            ebook.PrintInfo(); // Вызовет EBook.PrintInfo() (new)
            Publication pub3 = ebook;
            pub3.PrintInfo(); // Вызовет EBook.PrintInfo() (new)
        }
    }

    abstract class Publication
    {
        public abstract string Title { get; }
        public abstract void PrintInfo();
    }

    class Book2 : Publication
    {
        private string title;
        public int Pages;

        public string GetTitle() { return title; }
        public void SetTitle(string value) { title = value; }

        public Book2(string title)
        {
            this.title = title;
            Pages = 0;
        }

        public Book2(string title, int pages)
        {
            this.title = title;
            Pages = pages;
        }

        public string WriteInfo()
        {
            return $"Книга: {title}, страниц: {Pages}";
        }

        public void AddPages(int n)
        {
            Pages += n;
        }

        public override string Title => title;

        public override void PrintInfo()
        {
            Console.WriteLine($"Печатная книга: {Title}, {Pages} стр.");
        }
    }

    class EBook : Book2
    {
        public string Format;

        public EBook(string title, string format) : base(title)
        {
            Format = format;
        }

        // Скрытие (new) - нет полиморфизма
        public new void PrintInfo()
        {
            Console.WriteLine($"EBook специальная информация: {Title} в формате {Format}");
        }
    }
}