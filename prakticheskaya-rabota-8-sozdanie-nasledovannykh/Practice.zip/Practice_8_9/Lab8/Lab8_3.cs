﻿using System;

/*Абстрактный класс Publication заменить интерфейсом IPublication. Самостоятельно определить функциональность данного интерфейса;
Для класса EBook разработать интерфейс IDigital, производный от IPublication. Продемонстрировать явную реализацию интерфейса. Самостоятельно определить функциональность данного интерфейса;
Разработать класс Author. Добавить в класс Book объект этого класса в качестве поля, отражающего любимого автора книги;
Создать класс исключений PublicationException, прописать исключение через оператор throw в конструкторах класса Book и Author.
*/

namespace Practice_8_9.Lab9
{
    internal class Lab8_3
    {
        public void Test()
        {
            try
            {
                // Тест исключений
                Author author = new Author("Лев Толстой");
                Book3 book1 = new Book3("Война и мир", 1200, author); // Book3 вместо Book
                Console.WriteLine(book1.WriteInfo());

                // Явная реализация
                EBook2 ebook = new EBook2("1984", "PDF", author); 
                Console.WriteLine(ebook.GetInfo()); // Вызовет явную реализацию
                ebook.Download();

                // Полиморфизм через интерфейс
                IPublication pub = ebook;
                Console.WriteLine(pub.WriteInfo()); // Явная реализация IPublication.WriteInfo()
            }
            catch (PublicationException ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }
        }
    }

    // Интерфейсы
    interface IPublication
    {
        string Title { get; }
        int Pages { get; }
        string WriteInfo();
    }

    interface IDigital : IPublication
    {
        string Format { get; }
        void Download();
    }

    // Класс исключений
    class PublicationException : Exception
    {
        public PublicationException(string message) : base(message) { }
    }

    // Класс Author
    class Author
    {
        public string Name;

        public Author(string name)
        {
            if (string.IsNullOrEmpty(name))
                throw new PublicationException("Имя автора не может быть пустым");
            Name = name;
        }
    }

    // Обновленный класс Book
    class Book3 : IPublication
    {
        private string title;
        private int pages;
        public Author FavoriteAuthor;

        public Book3(string title) : this(title, 0, null) { }
        public Book3(string title, int pages) : this(title, pages, null) { }
        public Book3(string title, int pages, Author author)
        {
            if (string.IsNullOrEmpty(title))
                throw new PublicationException("Название книги не может быть пустым");
            if (pages < 0)
                throw new PublicationException("Количество страниц не может быть отрицательным");

            this.title = title;
            this.pages = pages;
            FavoriteAuthor = author;
        }

        // Реализация интерфейса IPublication
        public string Title => title;
        public int Pages => pages;

        public string WriteInfo()
        {
            string authorInfo = FavoriteAuthor != null ? $" (автор: {FavoriteAuthor.Name})" : "";
            return $"Книга: {title}, страниц: {pages}{authorInfo}";
        }
    }

    // Класс EBook с явной реализацией
    class EBook2 : IDigital
    {
        private string title;
        private string format;
        public Author FavoriteAuthor;
        public EBook2(string title, string format) : this(title, 0, format, null) { }
        public EBook2(string title, string format, Author author) : this(title, 0, format, author) { }
        public EBook2(string title, int pages, string format, Author author)
        {
            if (string.IsNullOrEmpty(title))
                throw new PublicationException("Название электронной книги не может быть пустым");
            this.title = title;
            this.format = format;
            FavoriteAuthor = author;
        }

        // Явная реализация IPublication
        string IPublication.Title => title;
        int IPublication.Pages => 0; // Электронная книга
        string IPublication.WriteInfo() => $"EBook: {title} ({format})";

        // Реализация IDigital
        public string Format => format;
        public void Download() => Console.WriteLine($"Скачиваю {title}.{format}");

        // Публичный метод для удобства
        public string GetInfo() => ((IPublication)this).WriteInfo();
    }
}