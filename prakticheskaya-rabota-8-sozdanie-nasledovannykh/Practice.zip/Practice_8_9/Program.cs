﻿using Practice_8_9.Lab8;
using Practice_8_9.Lab9;

internal class Program
{
    private static bool flag = true;
    private static void Main(string[] args)
    {
        while (flag)
        {
            Console.WriteLine("Выберите лабораторную работу:");
            Console.WriteLine("7 - Лабораторная работа 7");
            Console.WriteLine("8 - Лабораторная работа 8");
            Console.WriteLine("0 - выход");
            Console.WriteLine("1 - очистить консоль");
            Console.Write("Введите номер: ");

            int number = int.Parse(Console.ReadLine());

            switch (number)
            {
                case 0: flag = false;
                    Console.WriteLine("Завершение работы");
                    break;
                case 1: Console.Clear(); break;
                case 7:
                    Console.WriteLine("\nЛабораторная работа 8");
                    Console.WriteLine("Задание 1");
                    Lab7_1.Test();

                    Console.WriteLine("\nЗадание 2");
                    Lab7_2.Test();

                    Console.WriteLine("\nЗадание 3\n");
                    Lab7_3.Test();
                    break;

                case 8:
                    Console.WriteLine("\nЛабораторная работа 9\n");
                    Console.WriteLine("Задание 1\n");
                    Lab8_1.Test();

                    Console.WriteLine("\nЗадание 2");
                    Lab8_2 lab9_2 = new Lab8_2();
                    lab9_2.Test();

                    Console.WriteLine("\nЗадание 3\n");
                    Lab8_3 lab9_3 = new Lab8_3();
                    lab9_3.Test();
                    break;

                default:
                    Console.WriteLine("Лабораторной работы с таким номером не существует");
                    break;
            }
        }
    }
}