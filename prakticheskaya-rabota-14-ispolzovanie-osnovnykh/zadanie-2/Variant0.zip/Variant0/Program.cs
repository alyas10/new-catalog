﻿using System;
using System.Linq;

class Program
{
    static void Main()
    {
        // --- Вспомогательные локальные функции ---
        static CollectionType<int> CreateCollection(params int[] items)
        {
            var col = new CollectionType<int>();
            foreach (var item in items)
                col.Add(item);
            return col;
        }

        static void PrintCollection(CollectionType<int> col)
        {
            if (col.Count == 0)
            {
                Console.Write("(пустая)");
                return;
            }
            for (int i = 0; i < col.Count; i++)
            {
                Console.Write(col[i]);
                if (i < col.Count - 1) Console.Write(", ");
            }
        }

        // ===================================================
        //                 ЧАСТЬ 2: LINQ-ЗАПРОСЫ
        // ===================================================
        var collectionsList = new[]
        {
            CreateCollection(1, 3, 5),
            CreateCollection(2, 4, 6, 8),
            CreateCollection(10, 20),
            CreateCollection(7, 7, 7, 7, 7),
            CreateCollection(100),
            CreateCollection(), // пустая
            CreateCollection(9, 2, 5, 4, 6, 1)
        };

        Console.WriteLine("=== Часть 2: LINQ-запросы ===\n");

        // Запрос 1: Непустые → по возрастанию суммы → первые 3
        var q1 = collectionsList
            .Where(c => c.Count > 0)
            .OrderBy(c => c.Sum())
            .Take(3)
            .ToList();

        Console.WriteLine("1. Первые 3 непустые коллекции по возрастанию суммы:");
        foreach (var c in q1)
        {
            Console.Write("   Элементы: ");
            PrintCollection(c);
            Console.WriteLine($" → сумма = {c.Sum()}");
        }

        // Запрос 2: Есть ли коллекция, где все элементы чётные?
        bool q2 = collectionsList
            .Where(c => c.Count > 0)
            .Any(c => c.All(x => x % 2 == 0));

        Console.WriteLine($"\n2. Есть коллекция, где все элементы чётные? {q2}");

        // Запрос 3: Группы по размеру (более 1 коллекции)
        var q3 = collectionsList
            .GroupBy(c => c.Count)
            .Where(g => g.Count() > 1)
            .Select(g => new { Size = g.Key, Count = g.Count() })
            .OrderBy(x => x.Size)
            .ToList();

        Console.WriteLine("\n3. Группы по размеру (более 1 коллекции):");
        if (q3.Count == 0)
        {
            Console.WriteLine("   Нет таких групп.");
        }
        else
        {
            foreach (var g in q3)
                Console.WriteLine($"   Размер {g.Size}: {g.Count} шт.");
        }

        // Запрос 4: Минимальная сумма среди коллекций размером >= 3
        var largeCollections = collectionsList.Where(c => c.Count >= 3).ToList();
        if (largeCollections.Any())
        {
            int minSum = largeCollections.Min(c => c.Sum());
            Console.WriteLine($"\n4. Мин. сумма (размер ≥ 3): {minSum}");
        }
        else
        {
            Console.WriteLine("\n4. Мин. сумма (размер ≥ 3): нет подходящих коллекций");
        }

        // Запрос 5: Последние 3 уникальных чётных числа из всех коллекций
        var allEvenUnique = collectionsList
            .SelectMany(c => c)           // благодаря IEnumerable<T>!
            .Where(x => x % 2 == 0)
            .Distinct()
            .OrderBy(x => x)
            .ToList();

        var lastThree = allEvenUnique.Skip(Math.Max(0, allEvenUnique.Count - 3)).ToList();

        Console.WriteLine("\n5. Последние 3 уникальных чётных числа:");
        if (lastThree.Count == 0)
        {
            Console.WriteLine("   Нет чётных чисел.");
        }
        else
        {
            Console.Write("   ");
            for (int i = 0; i < lastThree.Count; i++)
            {
                Console.Write(lastThree[i]);
                if (i < lastThree.Count - 1) Console.Write(", ");
            }
            Console.WriteLine();
        }

        // ===================================================
        //                 ЧАСТЬ 3: МАССИВ + LINQ
        // ===================================================
        Console.WriteLine("\n=== Часть 3: Работа с массивом ===\n");

        var collectionsArray = new CollectionType<int>[]
        {
            CreateCollection(1, 2),
            CreateCollection(10, 20, 30),
            CreateCollection(5),
            CreateCollection(100, 200, 300, 400),
            CreateCollection(7, 8),
            CreateCollection() // пустая
        };

        int targetSize = 2;

        // 1. Количество коллекций заданного размера
        int countTarget = collectionsArray.Count(c => c.Count == targetSize);
        Console.WriteLine($"1. Количество коллекций размером {targetSize}: {countTarget}");

        // 2. Коллекция с максимальным размером
        var maxCol = collectionsArray.MaxBy(c => c.Count);
        Console.Write($"2. Максимальная коллекция (размер = {maxCol.Count}): ");
        PrintCollection(maxCol);
        Console.WriteLine();

        // 3. Коллекция с минимальным размером
        var minCol = collectionsArray.MinBy(c => c.Count);
        Console.Write($"3. Минимальная коллекция (размер = {minCol.Count}): ");
        PrintCollection(minCol);
        Console.WriteLine();
    }
}