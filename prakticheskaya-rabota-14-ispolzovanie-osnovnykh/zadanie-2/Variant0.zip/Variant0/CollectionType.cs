﻿
using System.Collections;
using System;
using System.Collections.Generic;

/// <summary>
/// Параметризованный класс коллекции на основе Dictionary
/// Реализует интерфейс IEnumerable<T> для поддержки foreach
/// </summary>
public class CollectionType<T> : IEnumerable<T>
{
    private Dictionary<int, T> _data;

    /// <summary>
    /// Конструктор по умолчанию
    /// </summary>
    public CollectionType()
    {
        _data = new Dictionary<int, T>();
    }

    /// <summary>
    /// Конструктор с начальной ёмкостью
    /// </summary>
    public CollectionType(int capacity)
    {
        if (capacity < 0)
            throw new ArgumentOutOfRangeException("capacity", "Ёмкость не может быть отрицательной.");
        _data = new Dictionary<int, T>(capacity);
    }

    /// <summary>
    /// Добавление элемента в конец коллекции
    /// </summary>
    public void Add(T item)
    {
        _data[_data.Count] = item;
    }

    /// <summary>
    /// Удаление первого вхождения элемента по значению
    /// </summary>
    public bool Remove(T item)
    {
        foreach (var kvp in _data)
        {
            if (EqualityComparer<T>.Default.Equals(kvp.Value, item))
            {
                int removedKey = kvp.Key;
                _data.Remove(removedKey);

                // Сдвигаем все элементы с ключами > removedKey
                var keysToShift = _data.Keys.Where(k => k > removedKey).OrderBy(k => k).ToList();
                foreach (var key in keysToShift)
                {
                    _data[key - 1] = _data[key];
                    _data.Remove(key);
                }

                return true;
            }
        }
        return false;
    }

    /// <summary>
    /// Удаление элемента по индексу
    /// </summary>
    public void RemoveAt(int index)
    {
        if (index < 0 || index >= _data.Count)
            throw new IndexOutOfRangeException("Индекс выходит за пределы коллекции.");

        // Удаляем элемент с ключом = index
        _data.Remove(index);

        // Сдвигаем все элементы с ключами > index на 1 влево
        var keysToShift = _data.Keys.Where(k => k > index).OrderBy(k => k).ToList();
        foreach (var key in keysToShift)
        {
            _data[key - 1] = _data[key];
            _data.Remove(key);
        }
    }

    /// <summary>
    /// Очистка коллекции
    /// </summary>
    public void Clear()
    {
        _data.Clear();
    }

    /// <summary>
    /// Проверка наличия элемента
    /// </summary>
    public bool Contains(T item)
    {
        return _data.ContainsValue(item);
    }

    /// <summary>
    /// Индексатор для доступа к элементам
    /// </summary>
    public T this[int index]
    {
        get
        {
            if (index < 0 || index >= _data.Count)
                throw new IndexOutOfRangeException("Индекс выходит за пределы коллекции.");
            return _data[index];
        }
        set
        {
            if (index < 0 || index >= _data.Count)
                throw new IndexOutOfRangeException("Индекс выходит за пределы коллекции.");
            _data[index] = value;
        }
    }

    /// <summary>
    /// Количество элементов в коллекции
    /// </summary>
    public int Count => _data.Count;

    /// <summary>
    /// Проверка, пуста ли коллекция
    /// </summary>
    public bool IsEmpty => _data.Count == 0;

    /// <summary>
    /// Оператор сравнения на равенство
    /// </summary>
    public static bool operator ==(CollectionType<T> a, CollectionType<T> b)
    {
        if (ReferenceEquals(a, b)) return true;
        if (a is null || b is null) return false;
        if (a.Count != b.Count) return false;

        for (int i = 0; i < a.Count; i++)
        {
            if (!EqualityComparer<T>.Default.Equals(a[i], b[i]))
                return false;
        }
        return true;
    }

    /// <summary>
    /// Оператор сравнения на неравенство
    /// </summary>
    public static bool operator !=(CollectionType<T> a, CollectionType<T> b)
    {
        return !(a == b);
    }

    /// <summary>
    /// Переопределение Equals
    /// </summary>
    public override bool Equals(object obj)
    {
        return obj is CollectionType<T> other && this == other;
    }

    /// <summary>
    /// Переопределение GetHashCode
    /// </summary>
    public override int GetHashCode()
    {
        int hash = 19;
        foreach (var item in _data.Values)
            hash = hash * 31 + (item?.GetHashCode() ?? 0);
        return hash;
    }

    /// <summary>
    /// Возвращает перечислитель для коллекции (IEnumerable<T>)
    /// Позволяет использовать foreach напрямую
    /// </summary>
    public IEnumerator<T> GetEnumerator()
    {
        for (int i = 0; i < _data.Count; i++)
        {
            yield return _data[i];
        }
    }

    /// <summary>
    /// Возвращает перечислитель для коллекции (IEnumerable)
    /// Необходимо для полной реализации IEnumerable
    /// </summary>
    IEnumerator IEnumerable.GetEnumerator()
    {
        return GetEnumerator();
    }

    /// <summary>
    /// Преобразует коллекцию в массив
    /// </summary>
    public T[] ToArray()
    {
        var array = new T[_data.Count];
        for (int i = 0; i < _data.Count; i++)
            array[i] = _data[i];
        return array;
    }

    /// <summary>
    /// Преобразует коллекцию в список
    /// </summary>
    public List<T> ToList()
    {
        var list = new List<T>(_data.Count);
        for (int i = 0; i < _data.Count; i++)
            list.Add(_data[i]);
        return list;
    }
}