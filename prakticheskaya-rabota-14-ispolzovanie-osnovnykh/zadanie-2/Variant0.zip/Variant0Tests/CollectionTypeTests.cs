﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Linq;

[TestClass]
public class CollectionTypeTests
{
    [TestMethod]
    public void Constructor_Default_CreatesEmptyCollection()
    {
        var collection = new CollectionType<int>();
        Assert.AreEqual(0, collection.Count);
        Assert.IsTrue(collection.IsEmpty);
    }

    [TestMethod]
    public void Constructor_WithCapacity_CreatesEmptyCollection()
    {
        var collection = new CollectionType<string>(5);
        Assert.AreEqual(0, collection.Count);
        Assert.IsTrue(collection.IsEmpty);
    }

    [TestMethod]
    [ExpectedException(typeof(ArgumentOutOfRangeException))]
    public void Constructor_NegativeCapacity_ThrowsException()
    {
        var collection = new CollectionType<double>(-1);
    }

    [TestMethod]
    public void Add_IncrementsCountAndStoresElementsInOrder()
    {
        var collection = new CollectionType<string>();
        collection.Add("A");
        collection.Add("B");
        collection.Add("C");

        Assert.AreEqual(3, collection.Count);
        Assert.AreEqual("A", collection[0]);
        Assert.AreEqual("B", collection[1]);
        Assert.AreEqual("C", collection[2]);

        // Проверка через foreach (благодаря IEnumerable<T>)
        var items = collection.ToList();
        CollectionAssert.AreEqual(new[] { "A", "B", "C" }, items);
    }

    [TestMethod]
    public void Indexer_Get_ReturnsCorrectValue()
    {
        var collection = new CollectionType<int>();
        collection.Add(10);
        collection.Add(20);

        Assert.AreEqual(10, collection[0]);
        Assert.AreEqual(20, collection[1]);
    }

    [TestMethod]
    public void Indexer_Set_UpdatesValue()
    {
        var collection = new CollectionType<string>();
        collection.Add("X");
        collection.Add("Y");

        collection[1] = "Z";

        Assert.AreEqual("X", collection[0]);
        Assert.AreEqual("Z", collection[1]);
    }

    [TestMethod]
    [ExpectedException(typeof(IndexOutOfRangeException))]
    public void Indexer_Get_InvalidIndex_ThrowsException()
    {
        var collection = new CollectionType<int>();
        collection.Add(100);
        var _ = collection[5];
    }

    [TestMethod]
    [ExpectedException(typeof(IndexOutOfRangeException))]
    public void Indexer_Set_InvalidIndex_ThrowsException()
    {
        var collection = new CollectionType<int>();
        collection.Add(100);
        collection[5] = 200;
    }

    [TestMethod]
    public void Remove_ExistingValue_RemovesFirstOccurrence()
    {
        var collection = new CollectionType<string>();
        collection.Add("A");
        collection.Add("B");
        collection.Add("A");

        bool removed = collection.Remove("A");

        Assert.IsTrue(removed);
        Assert.AreEqual(2, collection.Count);
        CollectionAssert.AreEqual(new[] { "B", "A" }, collection.ToList());
    }

    [TestMethod]
    public void Remove_NonExistingValue_ReturnsFalse()
    {
        var collection = new CollectionType<string>();
        collection.Add("X");

        bool removed = collection.Remove("Y");

        Assert.IsFalse(removed);
        Assert.AreEqual(1, collection.Count);
    }

    [TestMethod]
    public void RemoveAt_ValidIndex_RemovesElement()
    {
        var collection = new CollectionType<int>();
        collection.Add(10);
        collection.Add(20);
        collection.Add(30);

        collection.RemoveAt(1);

        Assert.AreEqual(2, collection.Count);
        CollectionAssert.AreEqual(new[] { 10, 30 }, collection.ToList());
    }

    [TestMethod]
    [ExpectedException(typeof(IndexOutOfRangeException))]
    public void RemoveAt_InvalidIndex_ThrowsException()
    {
        var collection = new CollectionType<int>();
        collection.Add(10);
        collection.RemoveAt(5);
    }

    [TestMethod]
    public void Clear_EmptiesCollection()
    {
        var collection = new CollectionType<char>();
        collection.Add('a');
        collection.Add('b');

        collection.Clear();

        Assert.AreEqual(0, collection.Count);
        Assert.IsTrue(collection.IsEmpty);
    }

    [TestMethod]
    public void Contains_ReturnsTrueForExistingElement()
    {
        var collection = new CollectionType<string>();
        collection.Add("Hello");
        collection.Add("World");

        Assert.IsTrue(collection.Contains("Hello"));
        Assert.IsTrue(collection.Contains("World"));
        Assert.IsFalse(collection.Contains("C#"));
    }

    [TestMethod]
    public void ToArray_ReturnsCorrectArray()
    {
        var collection = new CollectionType<int>();
        collection.Add(1);
        collection.Add(2);
        collection.Add(3);

        var array = collection.ToArray();
        CollectionAssert.AreEqual(new[] { 1, 2, 3 }, array);
    }

    [TestMethod]
    public void ToList_ReturnsCorrectList()
    {
        var collection = new CollectionType<string>();
        collection.Add("X");
        collection.Add("Y");

        var list = collection.ToList();
        CollectionAssert.AreEqual(new[] { "X", "Y" }, list);
    }

    [TestMethod]
    public void EqualityOperator_EqualCollections_ReturnsTrue()
    {
        var col1 = new CollectionType<int>();
        col1.Add(1); col1.Add(2);

        var col2 = new CollectionType<int>();
        col2.Add(1); col2.Add(2);

        Assert.IsTrue(col1 == col2);
        Assert.IsFalse(col1 != col2);
    }

    [TestMethod]
    public void EqualityOperator_DifferentCollections_ReturnsFalse()
    {
        var col1 = new CollectionType<string>();
        col1.Add("A"); col1.Add("B");

        var col2 = new CollectionType<string>();
        col2.Add("A"); col2.Add("C");

        Assert.IsTrue(col1 != col2);
        Assert.IsFalse(col1 == col2);
    }

    [TestMethod]
    public void EqualityOperator_NullHandling()
    {
        CollectionType<int> col1 = new();
        CollectionType<int> col2 = null;

        Assert.IsFalse(col1 == col2);
        Assert.IsTrue(col1 != col2);
    }

    [TestMethod]
    public void ImplementsIEnumerable_AllowsForeach()
    {
        var collection = new CollectionType<int>();
        collection.Add(5);
        collection.Add(10);
        collection.Add(15);

        int sum = 0;
        foreach (int item in collection)
        {
            sum += item;
        }

        Assert.AreEqual(30, sum);
    }
}